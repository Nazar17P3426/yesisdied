(!) yesisdied.exe by Hugopako (!)
hessfire has no skid so shut up N17Pro3426
if you reboot, Then MBR is Died!
Damage rate / Type: Destructive
